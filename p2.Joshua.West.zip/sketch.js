let content = [];
let weight = [];
let song;

let xStart = 0; //starting position of the text wall
let x1Start = 0;
let x = 0;
let xSpeed;
var a_video;
let offset = 0;
let easing = 0.05;
let counter = 0;
let R=150, G=150, B=150;
var WeatherAPI;
let headlines = [];
var newsURL = 'api.nytimes.com/svc/mostpopular/v2/viewed/1.json?api-key=tYwGE2u6VCRGjwB210rabHdpJeWiOyYo'
//let Cloudy, PartCloudy, Rain, Storm, Snow, Sun, Moon;



var weatherURL = 'https://api.openweathermap.org/data/2.5/weather?lat=33.5779&lon=-101.8552&appid=c4aa83fb9b0c902545632c8fbff0bbbe&units=imperial'

let myRec = new p5.SpeechRec;
myRec.continuous = false;
myRec.interimResults = true;

let myVoice = new p5.Speech();

function preload(){

Cloudy = loadImage('Data/icons8-clouds-64 (2).png');
PartCloudy = loadImage('Data/icons8-partly-cloudy-day-64 (1).png');
  Dang = loadImage('Data/Dang.png');

  

  song = loadSound('Data/Elder Scrolls 5 - Skyrim - 308 - Jeremy Soule - Blood And Steel.mp3');

  
  
  
  
table = loadTable('MyCalendar.csv', 'csv', 'header');
  
table2 = loadTable('Headlines.csv','csv','header'); 
  
table3 = loadTable('Weight.csv', 'csv', 'header');
  
}

function setup() {
 loadJSON(weatherURL, gotData);
  //loadJSON(newsURL, gotData2);
  
  
  frameRate(30);
  createCanvas(1920, 1050);
  background(51);
  a_video = createCapture(VIDEO);
  a_video.size(1920, 1050);
  a_video.hide();










textFont('Courier New');
  myRec.start();
  myRec.onResult = parseResult;
  myRec.onEnd = restartRec;

  //say hello


}


function gotData(data){ WeatherAPI = data;}


function draw() {
  
  
  var cYear = year();
  var cMonth = month();
  var cDay = day();
  var cHour = hour();
  var cMinute = minute();
  var cSecond = second();
  var DOTW = 'Monday';
  if(cDay % 7 == 1){DOTW = 'Tuesday'}
  if(cDay % 7 == 2){DOTW = 'Wednesday'}
  if(cDay % 7 == 3){DOTW = 'Thursday'}
  if(cDay % 7 == 4){DOTW = 'Friday'}
  if(cDay % 7 == 5){DOTW = 'Saturday'}
  if(cDay % 7 == 6){DOTW = 'Sunday'}
  if(cDay % 7 == 1){DOTW = 'Monday'}
  var MOTW = 'Jan';
  if(cMonth == 1){MOTW = 'Jan'}
  if(cMonth == 2){MOTW = 'Feb'}
  if(cMonth == 3){MOTW = 'Mar'}
  if(cMonth == 4){MOTW = 'Apr'}
  if(cMonth == 5){MOTW = 'May'}
  if(cMonth == 6){MOTW = 'Jun'}
  if(cMonth == 7){MOTW = 'Jul'}
  if(cMonth == 8){MOTW = 'Aug'}
  if(cMonth == 9){MOTW = 'Sep'}
  if(cMonth == 10){MOTW = 'Oct'}
  if(cMonth == 11){MOTW = 'Nov'}
  if(cMonth == 12){MOTW = 'Dec'}
  
  var cDate = cDay + '-' + cMonth + '-' + cYear;
  var cTime = cHour + ':' + cMinute;
  
  
  
  
  
  
  
  
  
  
  
  
  
  translate(a_video.width, 0);
  scale(-1,1);
  tint(R, G, B);

  image(a_video, 0, 0);
  
  translate(a_video.width, 0);
  scale(-1,1);
  fill(10,10,10);
  rect(0, 0, 1920, 50);
  
  //CLOCK

  stroke(0, 255, 255);
  strokeWeight(.5);
  
  
  
    tint(255, 255, 255);

  
  fill(255);
  textSize(50);
 
  
  if(cHour > 12){ 
    if(cMinute < 10 ){ text(cHour - 12 + ':0' + cMinute + 'pm', 120, 150);}
    else {text(cHour - 12 + ':' + cMinute + 'pm', 120, 150);}}                         
  if(cHour == 0){ 
    if(cMinute < 10 ){ text(12 + ':0' + cMinute + 'am', 120, 150);}
    else{text(12 + ':' + cMinute + 'am', 120, 150);}}
  if(cHour < 12 && cHour != 0){ 
     if(cMinute < 10 ){ text(cHour + ':0' + cMinute + 'am', 120, 150);}
      else{text(cHour + ':' + cMinute + 'am', 120, 150);}
      }
  
  textSize(30);


  
  fill(255);
  


 text(DOTW + ', ' + MOTW + ' ' + cDay + ', ' + cYear, 200, 100);
///END OF CLOCK

  
    fill(0, 255,255);

 text('Todays Activites', 160, 300); 
    fill(255);

  
  textSize(22);
  textAlign(LEFT);
let counter = 350;
for (let r = 0; r < table.getRowCount(); r++)
    for (let c = 0; c< table.getColumnCount(); c++){
      text(table.getString(r, c), 20, counter);
      counter = counter + 30;
    }
   textSize(30);
   textAlign(CENTER);

 let counter2 = 460;
for (let r = 0; r < table2.getRowCount(); r++)
    for (let c = 0; c< table2.getColumnCount(); c++){
      
      
      content[r] = table2.getString(r, c);
            counter2 = counter2 + 20;
    } 
let WC = 0, WR; 
for (let r = 0; r < table3.getRowCount(); r++)
    for (let c = 0; c< table3.getColumnCount(); c++){
      
      
      weight[r] = int(table3.getString(r, c));
      WC = WC + int(weight[r]);
      WR = r;
    }  
  WC = WC/(WR+1);
  
 if(WeatherAPI){
   fill(0, 255,255);

 text('Todays Weather', 140, 550); 
 text('Your Health', 110, 775); 
 text('News', 50, 1000); 

    fill(255);
   
   
   
   
    textSize(22);
  textAlign(LEFT);
   
   
textSize(50);
text(WeatherAPI.main.temp + 'F', 30, 610);
   textSize(22);
text('FL: ' + WeatherAPI.main.feels_like + 'F', 230, 590);
   text(' L: ' + WeatherAPI.main.temp_min + 'F', 230, 630);
   text(' H: ' + WeatherAPI.main.temp_max + 'F', 230, 610);
   
      text('HU: ' + WeatherAPI.main.humidity + '%', 230, 650);
      text('WS: ' + WeatherAPI.wind.speed + 'mph', 230, 670);

   
   
text(WeatherAPI.weather[0].main, 230, 690);
text(WeatherAPI.weather[0].description, 230, 710);
   
   
  text('Starting Weight: '+ weight[0] + ' lbs', 30, 815);
  text('Current Weight: '+ weight[WR] + ' lbs', 30, 835);
  text('Goal Weight: 165 lbs', 30, 855);
  text('Weight Lost: 22 lbs', 30, 875)
  text('Progress: 19%', 30, 895)
   
   
   
  textSize(30);
   textAlign(CENTER);
   
   let ID = 803;
   
   
   if(ID >= 200 && ID <= 232){image(Storm, 40, 620, 150, 150);}
    if(ID >= 300 && ID <= 321){image(Rain, 40, 625, 150, 150);}
   if(ID >= 500 && ID <= 531){image(Rain, 40, 625, 150, 150);}
    if(ID >= 600 && ID <= 622){image(Snow, 40, 625, 150, 150);}
    if(ID >= 700 && ID <= 782){}
    if(ID >= 801 && ID <= 802){image(PartCloudy, 40, 625, 150, 150);}
   if(ID >= 803 && ID <= 804){   image(Cloudy, 35, 610, 175, 175);}
     if(ID == 800){image(Sun, 40, 615, 150, 150);}

   if(DFLAG == true){image(Dang, 435, 210, 855, 855);}
   
   
  oldText();
   
  
}
    fill(255);

  
  
  
  
  
  
  
  
  
  
  
  



  
}

let index = 0;
function oldText() {

  
  
  
  
  
  
  
  
  
  
  
  
  
  let separator = '             ';
let content2 = join(content, separator);
     textAlign(LEFT); 
  textSize(22);

  
  
text(content2, x, height-20); 

  x = x - 3;

  var w = textWidth(content2); 
  if (x < -w) {
    x = width;
    index = (index + 1) % content2.length;
  }
   textAlign(CENTER); 

  
    
  
}

let DFLAG = false;
function parseResult() {
  //convert all results to lowercase
  let lowStr = myRec.resultString.toLowerCase();
  
  let mostrecentword = lowStr.split(' ').pop();

  if (mostrecentword.indexOf("red") !== -1) {
R = 255;G = 150; B = 150;
  } else if (mostrecentword.indexOf("green") !== -1) {

R = 150;G = 255; B = 150;
    //respond by color and speech
  } else if (mostrecentword.indexOf("blue") !== -1) {
  R = 150;G = 150; B = 255;


  } 
  
  
  else if (mostrecentword.indexOf("purple") !== -1) {
  R = 127;G = 0; B = 255;


  }
  
  
  
   else if (mostrecentword.indexOf("yellow") !== -1) {
  R = 255;G = 255; B = 51;


    //to stop the voice from repeating
  }
  
  
  
  
   else if (mostrecentword.indexOf("pink") !== -1) {
  R = 255;G = 153; B = 204;


    //to stop the voice from repeating
  }
   else if (mostrecentword.indexOf("orange") !== -1) {
  R = 255;G = 128; B = 0;


  }
   else if (mostrecentword.indexOf("default") !== -1) {
  R = 200;G = 200; B = 200;
     DFLAG = false;
if (song.isPlaying()) {
    song.stop();}
  }
  
  
   else if (mostrecentword.indexOf("intruder") !== -1) {
  R = 255;G = 0; B = 0;
    song.play();
  myVoice.speak('.... YOU NEVER SHOULD HAVE COME HERE!!!');
 
  }
  
     else if (mostrecentword.indexOf("beautiful") !== -1) {
  R = 255;G = 0; B = 200;
    DFLAG= true;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  else if (mostrecentword.indexOf("stop") !== -1) {
    myVoice.speak('ok.');
  } 

  console.log(mostrecentword);
}

//to make sure recognition restarts when it ends
function restartRec() {
  print("end");
  myRec.start();
}